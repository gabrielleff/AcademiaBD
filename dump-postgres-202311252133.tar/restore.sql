--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aulas_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aulas_grupo (
    id_aula integer NOT NULL,
    nome_aula character varying(50),
    instrutor character varying(50),
    capacidade_maxima integer
);


ALTER TABLE public.aulas_grupo OWNER TO postgres;

--
-- Name: equipamentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.equipamentos (
    id_equipamento integer NOT NULL,
    nome_equipamento character varying(50),
    descricao text
);


ALTER TABLE public.equipamentos OWNER TO postgres;

--
-- Name: membros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.membros (
    id_membro integer NOT NULL,
    id_usuario integer,
    data_inscricao date,
    tipo_membro character varying(50)
);


ALTER TABLE public.membros OWNER TO postgres;

--
-- Name: participacoes_aula; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participacoes_aula (
    id_participacao integer NOT NULL,
    id_membro integer,
    id_aula integer,
    data_participacao date
);


ALTER TABLE public.participacoes_aula OWNER TO postgres;

--
-- Name: registros_treino; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registros_treino (
    id_registro integer NOT NULL,
    id_membro integer,
    id_treino integer,
    data_registro date,
    calorias_queimadas integer,
    avaliacao integer
);


ALTER TABLE public.registros_treino OWNER TO postgres;

--
-- Name: reservas_equipamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reservas_equipamento (
    id_reserva integer NOT NULL,
    id_membro integer,
    id_equipamento integer,
    data_reserva date,
    hora_inicio time without time zone,
    hora_fim time without time zone
);


ALTER TABLE public.reservas_equipamento OWNER TO postgres;

--
-- Name: treinos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treinos (
    id_treino integer NOT NULL,
    nome_treino character varying(50),
    descricao text,
    duracao integer,
    dificuldade character varying(20)
);


ALTER TABLE public.treinos OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id_usuario integer NOT NULL,
    nome character varying(50),
    sobrenome character varying(50),
    data_nascimento date,
    email character varying(100),
    telefone character varying(15)
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Data for Name: aulas_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aulas_grupo (id_aula, nome_aula, instrutor, capacidade_maxima) FROM stdin;
\.
COPY public.aulas_grupo (id_aula, nome_aula, instrutor, capacidade_maxima) FROM '$$PATH$$/4888.dat';

--
-- Data for Name: equipamentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.equipamentos (id_equipamento, nome_equipamento, descricao) FROM stdin;
\.
COPY public.equipamentos (id_equipamento, nome_equipamento, descricao) FROM '$$PATH$$/4886.dat';

--
-- Data for Name: membros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.membros (id_membro, id_usuario, data_inscricao, tipo_membro) FROM stdin;
\.
COPY public.membros (id_membro, id_usuario, data_inscricao, tipo_membro) FROM '$$PATH$$/4883.dat';

--
-- Data for Name: participacoes_aula; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participacoes_aula (id_participacao, id_membro, id_aula, data_participacao) FROM stdin;
\.
COPY public.participacoes_aula (id_participacao, id_membro, id_aula, data_participacao) FROM '$$PATH$$/4889.dat';

--
-- Data for Name: registros_treino; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registros_treino (id_registro, id_membro, id_treino, data_registro, calorias_queimadas, avaliacao) FROM stdin;
\.
COPY public.registros_treino (id_registro, id_membro, id_treino, data_registro, calorias_queimadas, avaliacao) FROM '$$PATH$$/4885.dat';

--
-- Data for Name: reservas_equipamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reservas_equipamento (id_reserva, id_membro, id_equipamento, data_reserva, hora_inicio, hora_fim) FROM stdin;
\.
COPY public.reservas_equipamento (id_reserva, id_membro, id_equipamento, data_reserva, hora_inicio, hora_fim) FROM '$$PATH$$/4887.dat';

--
-- Data for Name: treinos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treinos (id_treino, nome_treino, descricao, duracao, dificuldade) FROM stdin;
\.
COPY public.treinos (id_treino, nome_treino, descricao, duracao, dificuldade) FROM '$$PATH$$/4884.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id_usuario, nome, sobrenome, data_nascimento, email, telefone) FROM stdin;
\.
COPY public.usuarios (id_usuario, nome, sobrenome, data_nascimento, email, telefone) FROM '$$PATH$$/4882.dat';

--
-- Name: aulas_grupo aulas_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aulas_grupo
    ADD CONSTRAINT aulas_grupo_pkey PRIMARY KEY (id_aula);


--
-- Name: equipamentos equipamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.equipamentos
    ADD CONSTRAINT equipamentos_pkey PRIMARY KEY (id_equipamento);


--
-- Name: membros membros_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_pkey PRIMARY KEY (id_membro);


--
-- Name: participacoes_aula participacoes_aula_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacoes_aula
    ADD CONSTRAINT participacoes_aula_pkey PRIMARY KEY (id_participacao);


--
-- Name: registros_treino registros_treino_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registros_treino
    ADD CONSTRAINT registros_treino_pkey PRIMARY KEY (id_registro);


--
-- Name: reservas_equipamento reservas_equipamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservas_equipamento
    ADD CONSTRAINT reservas_equipamento_pkey PRIMARY KEY (id_reserva);


--
-- Name: treinos treinos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treinos
    ADD CONSTRAINT treinos_pkey PRIMARY KEY (id_treino);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: membros membros_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id_usuario);


--
-- Name: participacoes_aula participacoes_aula_id_aula_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacoes_aula
    ADD CONSTRAINT participacoes_aula_id_aula_fkey FOREIGN KEY (id_aula) REFERENCES public.aulas_grupo(id_aula);


--
-- Name: participacoes_aula participacoes_aula_id_membro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participacoes_aula
    ADD CONSTRAINT participacoes_aula_id_membro_fkey FOREIGN KEY (id_membro) REFERENCES public.membros(id_membro);


--
-- Name: registros_treino registros_treino_id_membro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registros_treino
    ADD CONSTRAINT registros_treino_id_membro_fkey FOREIGN KEY (id_membro) REFERENCES public.membros(id_membro);


--
-- Name: registros_treino registros_treino_id_treino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registros_treino
    ADD CONSTRAINT registros_treino_id_treino_fkey FOREIGN KEY (id_treino) REFERENCES public.treinos(id_treino);


--
-- Name: reservas_equipamento reservas_equipamento_id_equipamento_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservas_equipamento
    ADD CONSTRAINT reservas_equipamento_id_equipamento_fkey FOREIGN KEY (id_equipamento) REFERENCES public.equipamentos(id_equipamento);


--
-- Name: reservas_equipamento reservas_equipamento_id_membro_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reservas_equipamento
    ADD CONSTRAINT reservas_equipamento_id_membro_fkey FOREIGN KEY (id_membro) REFERENCES public.membros(id_membro);


--
-- PostgreSQL database dump complete
--

